# models/user.py
from datetime import datetime
from extensions import db
from werkzeug.security import generate_password_hash, check_password_hash

# Si SerializableMixin está en un archivo separado, impórtalo
# from models.serializable_mixin import SerializableMixin # Ejemplo

class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(60), nullable=False, unique=True) # Añadir unique=True si no lo tiene

    # Esta relación 'users' en Role está bien
    users = db.relationship('User', backref='role', lazy=True)

class User(db.Model):
    __tablename__ = 'users'
    email = db.Column(db.String(120), primary_key=True)
    password_hash = db.Column(db.String(128), nullable=False)
    name = db.Column(db.String(50), nullable=False) # Este es el nombre del usuario o institución
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'), nullable=False)
    is_confirmed = db.Column(db.Boolean, default=False)
    last_password_reset = db.Column(db.DateTime, nullable=True, default=None)
    
    # --- NUEVAS RELACIONES ONE-TO-ONE ---
    # Relación uno-a-uno con StudentProfile
    # primaryjoin es necesario porque ambas tablas tienen 'email' y queremos especificar la condición
    # uselist=False indica que es una relación de uno (un User tiene un StudentProfile, no una lista)
    student_profile = db.relationship(
        'StudentProfile', 
        backref=db.backref('user', uselist=False), # El backref permite acceder a User desde StudentProfile como profile.user
        uselist=False, 
        primaryjoin="User.email == StudentProfile.email",
        foreign_keys="[StudentProfile.email]" # Especifica explícitamente la FK
    )

    # Relación uno-a-uno con InstitutionProfile
    institution_profile = db.relationship(
        'InstitutionProfile',
        backref=db.backref('user', uselist=False),
        uselist=False,
        primaryjoin="User.email == InstitutionProfile.email",
        foreign_keys="[InstitutionProfile.email]"
    )
    # -------------------------------------

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    # Tu método to_dict() del User (para API /me)
    def to_dict(self):
        data = {
            "email": self.email,
            "name": self.name,
            "role": self.role.name # Asume que Role está relacionado y tiene .name
        }
        # Puedes añadir otros campos de User si los necesitas aquí
        return data