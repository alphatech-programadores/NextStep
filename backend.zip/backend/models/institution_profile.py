# models/institution_profile.py
from extensions import db

class InstitutionProfile(db.Model):
    __tablename__ = 'institution_profiles'

    email = db.Column(db.String(120), db.ForeignKey('users.email'), primary_key=True)

    institution_name = db.Column(db.String(100), default="")
    contact_person = db.Column(db.String(100), default="")
    contact_phone = db.Column(db.String(20), default="")
    sector = db.Column(db.String(50), default="")
    address = db.Column(db.String(100), default="")
    description = db.Column(db.Text, default="")
    logo_url = db.Column(db.String(255), nullable=True, default=None)

    # --- ELIMINA CUALQUIER db.relationship QUE APUNTE A 'User' DESDE AQUÍ ---
    # Por ejemplo, si tenías algo como:
    # user_rel = db.relationship('User', backref=db.backref('institution_profile', uselist=False))
    # ¡BÓRRALO!