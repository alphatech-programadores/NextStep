# models/student_profile.py
from extensions import db
# from models.user import User # No es necesario importar si solo usas el ForeignKey
# Asegúrate de que SerializableMixin esté definido o importado si lo usas
class SerializableMixin:
    def to_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

class StudentProfile(db.Model, SerializableMixin):
    __tablename__ = 'student_profiles'

    email = db.Column(db.String(120), db.ForeignKey('users.email'), primary_key=True)
    career = db.Column(db.String(100), nullable=False, default="")
    semestre = db.Column(db.Integer, nullable=True)
    average = db.Column(db.Float)
    phone = db.Column(db.String(20), default="")
    address = db.Column(db.String(100), default="")
    availability = db.Column(db.String(100), default="")
    skills = db.Column(db.Text, default="")
    portfolio_url = db.Column(db.String(255), default="")
    cv_path = db.Column(db.String(255), nullable=True, default=None)
    profile_picture_url = db.Column(db.String(255), nullable=True, default=None)

    # --- ELIMINA CUALQUIER db.relationship QUE APUNTE A 'User' DESDE AQUÍ ---
    # Por ejemplo, si tenías algo como:
    # user_rel = db.relationship('User', backref=db.backref('student_profile', uselist=False))
    # ¡BÓRRALO!