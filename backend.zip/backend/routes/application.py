# En tu Blueprint de aplicaciones (ej. routes/application.py)

from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from extensions import db
from models.application import Application # Asegúrate de importar Application
from models.vacant import Vacant # Asegúrate de importar Vacant
from models.user import User # Asegúrate de importar User
from models.institution_profile import InstitutionProfile # Asegúrate de importar InstitutionProfile
from datetime import datetime

app_bp = Blueprint("application", __name__, url_prefix="/api/apply") # Usar el prefijo /api/apply como lo tienes en app.py

# No olvides aplicar CORS si no lo tienes globalmente
# from flask_cors import CORS
# CORS(app_bp)

@app_bp.route("/me", methods=["GET"])
@jwt_required()
def get_my_applications():
    current_user_email = get_jwt_identity()
    user = User.query.filter_by(email=current_user_email).first()

    if not user or user.role.name != 'student':
        return jsonify({"error": "Acceso denegado. Solo estudiantes pueden ver sus postulaciones."}), 403

    # Parámetros de filtro y paginación (opcional, para futuras mejoras)
    status_filter = request.args.get("status", "").strip()
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 10, type=int)

    query = Application.query.filter_by(student_email=user.email)

    if status_filter:
        query = query.filter_by(status=status_filter)

    # Unir con Vacant y InstitutionProfile para obtener detalles relevantes
    query = query.join(Vacant, Application.vacant_id == Vacant.id)\
                 .join(User, Vacant.institution_email == User.email)\
                 .join(InstitutionProfile, User.email == InstitutionProfile.email)

    # Ordenar por fecha de creación de la postulación (más reciente primero)
    query = query.order_by(Application.created_at.desc())

    paginated_applications = query.paginate(page=page, per_page=per_page, error_out=False)

    applications_list = []
    for app in paginated_applications.items:
        vacant = app.vacant # Acceder a la vacante relacionada
        institution_profile = vacant.institution_profile # Acceder al perfil de institución (requiere relación en Vacant)
        # Si no tienes estas relaciones directas en los modelos,
        # necesitarás hacer un query explícito:
        # institution_profile = InstitutionProfile.query.filter_by(email=vacant.institution_email).first()

        applications_list.append({
            "id": app.id,
            "vacant_id": vacant.id,
            "vacant_title": vacant.area, # Usar 'area' como título de vacante
            "company_name": institution_profile.institution_name if institution_profile else "Desconocido",
            "application_status": app.status,
            "applied_at": app.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "vacant_location": vacant.location,
            "vacant_modality": vacant.modality,
            "vacant_hours": vacant.hours # Usar 'hours' como rango salarial/horas
        })

    return jsonify({
        "applications": applications_list,
        "total_pages": paginated_applications.pages,
        "current_page": paginated_applications.page,
        "total_items": paginated_applications.total
    }), 200

# Recuerda registrar este Blueprint en tu app principal (ej. app.py)
# app.register_blueprint(app_bp, url_prefix="/api/apply")